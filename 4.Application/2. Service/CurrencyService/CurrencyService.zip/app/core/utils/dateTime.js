'use strict'
const dateFormat = require('dateformat');

module.exports = {
    dateFormat: dateFormat
}