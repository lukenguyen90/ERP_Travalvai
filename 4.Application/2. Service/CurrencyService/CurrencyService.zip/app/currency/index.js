'use strict'
module.exports = {
    service: require('./service')
}